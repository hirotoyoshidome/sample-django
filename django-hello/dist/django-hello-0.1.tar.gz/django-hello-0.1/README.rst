 INSTALLED_APPS = [
        ...
        'hello',
 ]


 path('hello/', include('hello.urls')),


 ```
 python3 manage.py migrate
 ```


